package com.bank.frauddetection.repository;

import com.bank.frauddetection.entity.FraudAlert;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FraudAlertRepository extends JpaRepository<FraudAlert, Long> {
    List<FraudAlert> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<FraudAlert> findByStatusOrderByCreatedAtDesc(FraudAlert.AlertStatus status);
    List<FraudAlert> findAllByOrderByCreatedAtDesc();
}
