package com.bank.frauddetection.controller;

import com.bank.frauddetection.entity.Account;
import com.bank.frauddetection.entity.FraudAlert;
import com.bank.frauddetection.entity.User;
import com.bank.frauddetection.repository.FraudAlertRepository;
import com.bank.frauddetection.repository.UserRepository;
import com.bank.frauddetection.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Admin-only endpoints. Access is restricted to ROLE_ADMIN via SecurityConfig
 * (/api/admin/** requires hasAuthority("ROLE_ADMIN")).
 */
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final AccountService accountService;
    private final FraudAlertRepository fraudAlertRepository;

    @GetMapping("/customers")
    public List<User> listCustomers() {
        return userRepository.findAll();
    }

    @PostMapping("/accounts/{accountNumber}/freeze")
    public Account freezeAccount(@PathVariable String accountNumber) {
        return accountService.freezeAccount(accountNumber);
    }

    @PostMapping("/accounts/{accountNumber}/unfreeze")
    public Account unfreezeAccount(@PathVariable String accountNumber) {
        return accountService.unfreezeAccount(accountNumber);
    }

    @GetMapping("/fraud-alerts")
    public List<FraudAlert> allFraudAlerts() {
        return fraudAlertRepository.findAllByOrderByCreatedAtDesc();
    }

    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() {
        long totalCustomers = userRepository.count();
        long openAlerts = fraudAlertRepository.findByStatusOrderByCreatedAtDesc(FraudAlert.AlertStatus.OPEN).size();

        return Map.of(
                "totalCustomers", totalCustomers,
                "openFraudAlerts", openAlerts
        );
    }
}
