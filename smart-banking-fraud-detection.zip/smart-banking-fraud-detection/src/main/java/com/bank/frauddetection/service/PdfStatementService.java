package com.bank.frauddetection.service;

import com.bank.frauddetection.entity.Account;
import com.bank.frauddetection.entity.Transaction;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Generates a downloadable PDF account statement for a given account and
 * a list of transactions using iText.
 */
@Service
public class PdfStatementService {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    public byte[] generateStatement(Account account, List<Transaction> transactions) {
        try {
            Document document = new Document(PageSize.A4, 36, 36, 54, 36);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            PdfWriter.getInstance(document, out);
            document.open();

            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            Font normalFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
            Font smallFont = new Font(Font.FontFamily.HELVETICA, 9, Font.NORMAL, BaseColor.GRAY);

            Paragraph title = new Paragraph("Smart Banking - Account Statement", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            Paragraph accInfo = new Paragraph();
            accInfo.add(new Chunk("Account Holder: ", getBoldFont()));
            accInfo.add(new Chunk(account.getUser().getFullName() + "\n", normalFont));
            accInfo.add(new Chunk("Account Number: ", getBoldFont()));
            accInfo.add(new Chunk(account.getAccountNumber() + "\n", normalFont));
            accInfo.add(new Chunk("Current Balance: ", getBoldFont()));
            accInfo.add(new Chunk("Rs. " + account.getBalance() + "\n", normalFont));
            accInfo.add(new Chunk("Account Status: ", getBoldFont()));
            accInfo.add(new Chunk(account.getStatus().name() + "\n", normalFont));
            document.add(accInfo);
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{2.5f, 1.5f, 2f, 1.8f, 1.8f, 1.5f});

            String[] columns = {"Date", "Reference", "Type", "Amount (Rs.)", "Balance After", "Status"};
            for (String col : columns) {
                PdfPCell cell = new PdfPCell(new Phrase(col, headerFont));
                cell.setBackgroundColor(new BaseColor(30, 60, 114));
                cell.setPadding(6);
                table.addCell(cell);
            }

            for (Transaction t : transactions) {
                table.addCell(new Phrase(t.getTimestamp().format(FORMATTER), normalFont));
                table.addCell(new Phrase(t.getReferenceId(), normalFont));
                table.addCell(new Phrase(t.getType().name(), normalFont));
                table.addCell(new Phrase(t.getAmount().toString(), normalFont));
                table.addCell(new Phrase(t.getBalanceAfter().toString(), normalFont));
                table.addCell(new Phrase(t.getStatus().name(), normalFont));
            }

            if (transactions.isEmpty()) {
                PdfPCell empty = new PdfPCell(new Phrase("No transactions found for this account.", normalFont));
                empty.setColspan(6);
                empty.setPadding(8);
                table.addCell(empty);
            }

            document.add(table);
            document.add(Chunk.NEWLINE);

            Paragraph footer = new Paragraph(
                    "This is a system-generated statement from the Smart Banking & Fraud Anomaly Detection System.",
                    smallFont);
            footer.setAlignment(Element.ALIGN_CENTER);
            document.add(footer);

            document.close();
            return out.toByteArray();
        } catch (DocumentException e) {
            throw new RuntimeException("Failed to generate PDF statement", e);
        }
    }

    private Font getBoldFont() {
        return new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
    }
}
