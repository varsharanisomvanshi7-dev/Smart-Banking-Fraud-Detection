package com.bank.frauddetection.controller;

import com.bank.frauddetection.dto.AmountRequest;
import com.bank.frauddetection.dto.TransactionResponse;
import com.bank.frauddetection.dto.TransferRequest;
import com.bank.frauddetection.entity.Account;
import com.bank.frauddetection.entity.Transaction;
import com.bank.frauddetection.service.AccountService;
import com.bank.frauddetection.service.PdfStatementService;
import com.bank.frauddetection.service.TransactionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;
    private final AccountService accountService;
    private final PdfStatementService pdfStatementService;

    @PostMapping("/deposit")
    public ResponseEntity<TransactionResponse> deposit(@Valid @RequestBody AmountRequest request) {
        Account account = accountService.getByAccountNumber(request.getAccountNumber());
        Transaction t = transactionService.deposit(account, request.getAmount());
        return ResponseEntity.ok(toResponse(t));
    }

    @PostMapping("/withdraw")
    public ResponseEntity<TransactionResponse> withdraw(@Valid @RequestBody AmountRequest request) {
        Account account = accountService.getByAccountNumber(request.getAccountNumber());
        Transaction t = transactionService.withdraw(account, request.getAmount());
        return ResponseEntity.ok(toResponse(t));
    }

    @PostMapping("/transfer")
    public ResponseEntity<TransactionResponse> transfer(@Valid @RequestBody TransferRequest request) {
        Account source = accountService.getByAccountNumber(request.getSourceAccountNumber());
        Account destination = accountService.getByAccountNumber(request.getDestinationAccountNumber());
        Transaction t = transactionService.transfer(source, destination, request.getAmount(), request.getRemarks());
        return ResponseEntity.ok(toResponse(t));
    }

    @GetMapping("/history/{accountNumber}")
    public ResponseEntity<List<TransactionResponse>> history(@PathVariable String accountNumber) {
        Account account = accountService.getByAccountNumber(accountNumber);
        List<TransactionResponse> history = transactionService.getHistory(account).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(history);
    }

    @GetMapping("/statement/{accountNumber}")
    public ResponseEntity<byte[]> statement(@PathVariable String accountNumber) {
        Account account = accountService.getByAccountNumber(accountNumber);
        List<Transaction> history = transactionService.getHistory(account);
        byte[] pdf = pdfStatementService.generateStatement(account, history);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=statement-" + accountNumber + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }

    private TransactionResponse toResponse(Transaction t) {
        return TransactionResponse.builder()
                .referenceId(t.getReferenceId())
                .type(t.getType().name())
                .sourceAccountNumber(t.getSourceAccount() != null ? t.getSourceAccount().getAccountNumber() : null)
                .destinationAccountNumber(t.getDestinationAccount() != null ? t.getDestinationAccount().getAccountNumber() : null)
                .amount(t.getAmount())
                .balanceAfter(t.getBalanceAfter())
                .status(t.getStatus().name())
                .remarks(t.getRemarks())
                .timestamp(t.getTimestamp())
                .build();
    }
}
