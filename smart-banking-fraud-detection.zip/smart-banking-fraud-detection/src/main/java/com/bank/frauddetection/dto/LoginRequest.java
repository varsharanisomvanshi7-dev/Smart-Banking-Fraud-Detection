package com.bank.frauddetection.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class LoginRequest {
    @NotBlank
    private String email;

    @NotBlank
    private String password;

    // Optional client-supplied context, used by fraud detection rules
    private String city;
    private String deviceInfo;
}
