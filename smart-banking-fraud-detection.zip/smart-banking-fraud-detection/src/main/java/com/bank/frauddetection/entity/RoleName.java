package com.bank.frauddetection.entity;

public enum RoleName {
    ROLE_CUSTOMER,
    ROLE_ADMIN
}
