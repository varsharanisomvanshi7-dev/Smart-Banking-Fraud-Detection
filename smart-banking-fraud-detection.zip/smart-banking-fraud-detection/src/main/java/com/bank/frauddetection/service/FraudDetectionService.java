package com.bank.frauddetection.service;

import com.bank.frauddetection.entity.*;
import com.bank.frauddetection.repository.FraudAlertRepository;
import com.bank.frauddetection.repository.LoginHistoryRepository;
import com.bank.frauddetection.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Rule-based fraud detection engine.
 * Implements the fraud rules defined in the project spec:
 *   - Transfer amount above threshold (default > 1,00,000)
 *   - Multiple logins from different cities in a short window
 *   - More than N transfers within a rolling window (default 5 in 10 mins)
 *   - Multiple failed login attempts
 *   - Login from an unrecognized device
 *   - Sudden large withdrawal relative to typical balance
 */
@Service
@RequiredArgsConstructor
public class FraudDetectionService {

    private final FraudAlertRepository fraudAlertRepository;
    private final TransactionRepository transactionRepository;
    private final LoginHistoryRepository loginHistoryRepository;
    private final NotificationService notificationService;

    @Value("${fraud.rule.high-amount-threshold}")
    private BigDecimal highAmountThreshold;

    @Value("${fraud.rule.max-transfers-per-window}")
    private int maxTransfersPerWindow;

    @Value("${fraud.rule.window-minutes}")
    private int windowMinutes;

    @Value("${fraud.rule.max-failed-logins}")
    private int maxFailedLogins;

    /**
     * Evaluate a transaction (deposit/withdraw/transfer) against fraud rules.
     * Returns true if the transaction was flagged.
     */
    public boolean evaluateTransaction(User user, Account sourceAccount, Transaction transaction) {
        boolean flagged = false;

        // Rule: high amount transfer
        if (transaction.getAmount().compareTo(highAmountThreshold) > 0) {
            raiseAlert(user, transaction, FraudAlert.FraudRuleType.HIGH_AMOUNT_TRANSFER,
                    "Transaction amount ₹" + transaction.getAmount() + " exceeds the high-value threshold of ₹" + highAmountThreshold,
                    FraudAlert.Severity.HIGH);
            flagged = true;
        }

        // Rule: frequent transactions (more than N transfers within window)
        if (sourceAccount != null) {
            LocalDateTime since = LocalDateTime.now().minusMinutes(windowMinutes);
            List<Transaction> recent = transactionRepository.findRecentOutgoingTransactions(sourceAccount, since);
            if (recent.size() + 1 > maxTransfersPerWindow) {
                raiseAlert(user, transaction, FraudAlert.FraudRuleType.FREQUENT_TRANSACTIONS,
                        "More than " + maxTransfersPerWindow + " transfers detected within " + windowMinutes + " minutes",
                        FraudAlert.Severity.MEDIUM);
                flagged = true;
            }
        }

        // Rule: sudden balance withdrawal (withdrawal/transfer > 80% of remaining balance)
        if (sourceAccount != null && transaction.getType() != Transaction.TransactionType.DEPOSIT) {
            BigDecimal preTransactionBalance = transaction.getBalanceAfter().add(transaction.getAmount());
            if (preTransactionBalance.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal ratio = transaction.getAmount().divide(preTransactionBalance, 4, java.math.RoundingMode.HALF_UP);
                if (ratio.compareTo(new BigDecimal("0.80")) >= 0) {
                    raiseAlert(user, transaction, FraudAlert.FraudRuleType.SUDDEN_BALANCE_WITHDRAWAL,
                            "Withdrawal/transfer represents " + ratio.multiply(BigDecimal.valueOf(100)) + "% of account balance",
                            FraudAlert.Severity.HIGH);
                    flagged = true;
                }
            }
        }

        return flagged;
    }

    /**
     * Evaluate a login attempt against fraud rules.
     * Returns true if the login was flagged as suspicious.
     */
    public boolean evaluateLogin(User user, LoginHistory currentLogin) {
        boolean flagged = false;

        if (!currentLogin.isSuccess()) {
            // Rule: multiple failed login attempts
            if (user.getFailedLoginAttempts() + 1 >= maxFailedLogins) {
                raiseLoginAlert(user, FraudAlert.FraudRuleType.MULTIPLE_FAILED_LOGINS,
                        "User has " + (user.getFailedLoginAttempts() + 1) + " consecutive failed login attempts",
                        FraudAlert.Severity.HIGH);
                flagged = true;
            }
            return flagged;
        }

        // Rule: multiple login locations within short window
        LocalDateTime since = LocalDateTime.now().minusHours(1);
        List<LoginHistory> recentLogins = loginHistoryRepository
                .findByUserAndLoginTimeAfterOrderByLoginTimeDesc(user, since);

        Set<String> distinctCities = recentLogins.stream()
                .map(LoginHistory::getCity)
                .filter(c -> c != null && !c.isBlank())
                .collect(Collectors.toSet());
        if (currentLogin.getCity() != null && !currentLogin.getCity().isBlank()) {
            distinctCities.add(currentLogin.getCity());
        }

        if (distinctCities.size() > 1) {
            raiseLoginAlert(user, FraudAlert.FraudRuleType.MULTIPLE_LOGIN_LOCATIONS,
                    "Logins detected from multiple cities within the last hour: " + distinctCities,
                    FraudAlert.Severity.HIGH);
            flagged = true;
        }

        // Rule: unknown device
        boolean knownDevice = recentLogins.stream()
                .anyMatch(l -> currentLogin.getDeviceInfo() != null
                        && currentLogin.getDeviceInfo().equals(l.getDeviceInfo()));
        if (!recentLogins.isEmpty() && !knownDevice && currentLogin.getDeviceInfo() != null) {
            raiseLoginAlert(user, FraudAlert.FraudRuleType.UNKNOWN_DEVICE_LOGIN,
                    "Login detected from a previously unseen device: " + currentLogin.getDeviceInfo(),
                    FraudAlert.Severity.MEDIUM);
            flagged = true;
        }

        return flagged;
    }

    private void raiseAlert(User user, Transaction transaction, FraudAlert.FraudRuleType rule,
                             String description, FraudAlert.Severity severity) {
        FraudAlert alert = FraudAlert.builder()
                .user(user)
                .transaction(transaction)
                .ruleTriggered(rule)
                .description(description)
                .severity(severity)
                .status(FraudAlert.AlertStatus.OPEN)
                .build();
        fraudAlertRepository.save(alert);
        notificationService.sendFraudAlertNotification(user, description);
    }

    private void raiseLoginAlert(User user, FraudAlert.FraudRuleType rule,
                                  String description, FraudAlert.Severity severity) {
        FraudAlert alert = FraudAlert.builder()
                .user(user)
                .transaction(null)
                .ruleTriggered(rule)
                .description(description)
                .severity(severity)
                .status(FraudAlert.AlertStatus.OPEN)
                .build();
        fraudAlertRepository.save(alert);
        notificationService.sendFraudAlertNotification(user, description);
    }
}
