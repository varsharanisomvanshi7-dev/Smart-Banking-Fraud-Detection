package com.bank.frauddetection.service;

import com.bank.frauddetection.entity.Account;
import com.bank.frauddetection.entity.Transaction;
import com.bank.frauddetection.entity.User;
import com.bank.frauddetection.exception.AccountFrozenException;
import com.bank.frauddetection.exception.InsufficientBalanceException;
import com.bank.frauddetection.repository.AccountRepository;
import com.bank.frauddetection.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

/**
 * Handles money movement. All state-changing operations are @Transactional
 * so that a failure partway through (e.g. insufficient balance, frozen
 * account) causes a full rollback - no partial debit/credit is ever
 * persisted (ACID guarantee).
 */
@Service
@RequiredArgsConstructor
public class TransactionService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final FraudDetectionService fraudDetectionService;
    private final NotificationService notificationService;
    private final AuditService auditService;

    @Transactional
    public Transaction deposit(Account account, BigDecimal amount) {
        assertActive(account);

        account.setBalance(account.getBalance().add(amount));
        accountRepository.save(account);

        Transaction transaction = Transaction.builder()
                .referenceId(generateReference())
                .sourceAccount(null)
                .destinationAccount(account)
                .type(Transaction.TransactionType.DEPOSIT)
                .amount(amount)
                .balanceAfter(account.getBalance())
                .status(Transaction.TransactionStatus.SUCCESS)
                .remarks("Cash deposit")
                .build();
        transaction = transactionRepository.save(transaction);

        boolean flagged = fraudDetectionService.evaluateTransaction(account.getUser(), null, transaction);
        if (flagged) {
            transaction.setStatus(Transaction.TransactionStatus.FLAGGED);
            transactionRepository.save(transaction);
        }

        notificationService.sendTransactionNotification(account.getUser(),
                "Deposit of ₹" + amount + " credited to account " + account.getAccountNumber());
        auditService.log(account.getUser().getEmail(), "DEPOSIT", "₹" + amount + " into " + account.getAccountNumber());

        return transaction;
    }

    @Transactional
    public Transaction withdraw(Account account, BigDecimal amount) {
        assertActive(account);

        if (account.getBalance().compareTo(amount) < 0) {
            throw new InsufficientBalanceException("Insufficient balance in account " + account.getAccountNumber());
        }

        account.setBalance(account.getBalance().subtract(amount));
        accountRepository.save(account);

        Transaction transaction = Transaction.builder()
                .referenceId(generateReference())
                .sourceAccount(account)
                .destinationAccount(null)
                .type(Transaction.TransactionType.WITHDRAW)
                .amount(amount)
                .balanceAfter(account.getBalance())
                .status(Transaction.TransactionStatus.SUCCESS)
                .remarks("Cash withdrawal")
                .build();
        transaction = transactionRepository.save(transaction);

        boolean flagged = fraudDetectionService.evaluateTransaction(account.getUser(), account, transaction);
        if (flagged) {
            transaction.setStatus(Transaction.TransactionStatus.FLAGGED);
            transactionRepository.save(transaction);
        }

        notificationService.sendTransactionNotification(account.getUser(),
                "Withdrawal of ₹" + amount + " from account " + account.getAccountNumber());
        auditService.log(account.getUser().getEmail(), "WITHDRAW", "₹" + amount + " from " + account.getAccountNumber());

        return transaction;
    }

    /**
     * Transfers funds between two accounts atomically. If any check fails
     * (frozen account, insufficient balance) the entire operation is rolled
     * back automatically by Spring's transaction management.
     */
    @Transactional
    public Transaction transfer(Account source, Account destination, BigDecimal amount, String remarks) {
        assertActive(source);
        assertActive(destination);

        if (source.getAccountNumber().equals(destination.getAccountNumber())) {
            throw new IllegalArgumentException("Source and destination accounts must be different");
        }

        if (source.getBalance().compareTo(amount) < 0) {
            throw new InsufficientBalanceException("Insufficient balance in account " + source.getAccountNumber());
        }

        source.setBalance(source.getBalance().subtract(amount));
        destination.setBalance(destination.getBalance().add(amount));
        accountRepository.save(source);
        accountRepository.save(destination);

        Transaction transaction = Transaction.builder()
                .referenceId(generateReference())
                .sourceAccount(source)
                .destinationAccount(destination)
                .type(Transaction.TransactionType.TRANSFER)
                .amount(amount)
                .balanceAfter(source.getBalance())
                .status(Transaction.TransactionStatus.SUCCESS)
                .remarks(remarks != null ? remarks : "Fund transfer")
                .build();
        transaction = transactionRepository.save(transaction);

        boolean flagged = fraudDetectionService.evaluateTransaction(source.getUser(), source, transaction);
        if (flagged) {
            transaction.setStatus(Transaction.TransactionStatus.FLAGGED);
            transactionRepository.save(transaction);
        }

        notificationService.sendTransactionNotification(source.getUser(),
                "₹" + amount + " transferred to " + destination.getAccountNumber());
        notificationService.sendTransactionNotification(destination.getUser(),
                "₹" + amount + " received from " + source.getAccountNumber());
        auditService.log(source.getUser().getEmail(), "TRANSFER",
                "₹" + amount + " from " + source.getAccountNumber() + " to " + destination.getAccountNumber());

        return transaction;
    }

    public List<Transaction> getHistory(Account account) {
        return transactionRepository.findBySourceAccountOrDestinationAccountOrderByTimestampDesc(account, account);
    }

    private void assertActive(Account account) {
        if (account.getStatus() != Account.AccountStatus.ACTIVE) {
            throw new AccountFrozenException("Account " + account.getAccountNumber() + " is " + account.getStatus()
                    + " and cannot be used for transactions");
        }
    }

    private String generateReference() {
        return "TXN-" + UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
    }
}
