package com.bank.frauddetection.repository;

import com.bank.frauddetection.entity.Account;
import com.bank.frauddetection.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    List<Transaction> findBySourceAccountOrDestinationAccountOrderByTimestampDesc(
            Account sourceAccount, Account destinationAccount);

    @Query("SELECT t FROM Transaction t WHERE t.sourceAccount = :account " +
           "AND t.timestamp >= :since ORDER BY t.timestamp DESC")
    List<Transaction> findRecentOutgoingTransactions(@Param("account") Account account,
                                                       @Param("since") LocalDateTime since);
}
