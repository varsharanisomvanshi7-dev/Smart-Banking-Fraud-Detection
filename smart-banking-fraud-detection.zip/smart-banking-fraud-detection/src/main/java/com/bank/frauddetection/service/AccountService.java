package com.bank.frauddetection.service;

import com.bank.frauddetection.entity.Account;
import com.bank.frauddetection.entity.User;
import com.bank.frauddetection.exception.ResourceNotFoundException;
import com.bank.frauddetection.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AccountService {

    private final AccountRepository accountRepository;
    private final AuditService auditService;
    private static final SecureRandom RANDOM = new SecureRandom();

    @Transactional
    public Account createAccount(User user, BigDecimal initialDeposit) {
        Account account = Account.builder()
                .accountNumber(generateAccountNumber())
                .user(user)
                .balance(initialDeposit != null ? initialDeposit : BigDecimal.ZERO)
                .status(Account.AccountStatus.ACTIVE)
                .build();

        account = accountRepository.save(account);
        auditService.log(user.getEmail(), "CREATE_ACCOUNT", "New account " + account.getAccountNumber() + " opened");
        return account;
    }

    public List<Account> getAccountsForUser(User user) {
        return accountRepository.findByUser(user);
    }

    public Account getByAccountNumber(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + accountNumber));
    }

    public BigDecimal getBalance(String accountNumber) {
        return getByAccountNumber(accountNumber).getBalance();
    }

    @Transactional
    public Account freezeAccount(String accountNumber) {
        Account account = getByAccountNumber(accountNumber);
        account.setStatus(Account.AccountStatus.FROZEN);
        accountRepository.save(account);
        auditService.log("ADMIN", "FREEZE_ACCOUNT", "Account " + accountNumber + " frozen");
        return account;
    }

    @Transactional
    public Account unfreezeAccount(String accountNumber) {
        Account account = getByAccountNumber(accountNumber);
        account.setStatus(Account.AccountStatus.ACTIVE);
        accountRepository.save(account);
        auditService.log("ADMIN", "UNFREEZE_ACCOUNT", "Account " + accountNumber + " reactivated");
        return account;
    }

    /**
     * Generates a unique 12-digit account number.
     */
    private String generateAccountNumber() {
        String candidate;
        do {
            StringBuilder sb = new StringBuilder("40");
            for (int i = 0; i < 10; i++) {
                sb.append(RANDOM.nextInt(10));
            }
            candidate = sb.toString();
        } while (accountRepository.findByAccountNumber(candidate).isPresent());
        return candidate;
    }
}
