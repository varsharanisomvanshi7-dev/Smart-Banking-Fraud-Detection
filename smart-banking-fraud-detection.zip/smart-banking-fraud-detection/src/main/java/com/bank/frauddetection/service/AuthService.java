package com.bank.frauddetection.service;

import com.bank.frauddetection.dto.AuthResponse;
import com.bank.frauddetection.dto.LoginRequest;
import com.bank.frauddetection.dto.RegisterRequest;
import com.bank.frauddetection.entity.LoginHistory;
import com.bank.frauddetection.entity.RoleName;
import com.bank.frauddetection.entity.User;
import com.bank.frauddetection.exception.DuplicateResourceException;
import com.bank.frauddetection.repository.LoginHistoryRepository;
import com.bank.frauddetection.repository.UserRepository;
import com.bank.frauddetection.security.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final LoginHistoryRepository loginHistoryRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final FraudDetectionService fraudDetectionService;
    private final AuditService auditService;

    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("An account with this email already exists");
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .phoneNumber(request.getPhoneNumber())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(RoleName.ROLE_CUSTOMER)
                .build();

        user = userRepository.save(user);
        auditService.log(user.getEmail(), "REGISTER", "New customer account created");

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        return AuthResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .fullName(user.getFullName())
                .email(user.getEmail())
                .role(user.getRole().name())
                .build();
    }

    @Transactional
    public AuthResponse login(LoginRequest request, HttpServletRequest httpRequest) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new BadCredentialsException("Invalid email or password"));

        if (!user.isAccountNonLocked()) {
            throw new LockedException("Account is locked due to suspicious activity. Contact support.");
        }

        boolean matches = passwordEncoder.matches(request.getPassword(), user.getPassword());

        LoginHistory loginHistory = LoginHistory.builder()
                .user(user)
                .ipAddress(resolveClientIp(httpRequest))
                .city(request.getCity())
                .deviceInfo(request.getDeviceInfo() != null ? request.getDeviceInfo() : httpRequest.getHeader("User-Agent"))
                .success(matches)
                .build();
        loginHistory = loginHistoryRepository.save(loginHistory);

        if (!matches) {
            user.setFailedLoginAttempts(user.getFailedLoginAttempts() + 1);
            boolean flagged = fraudDetectionService.evaluateLogin(user, loginHistory);
            if (flagged && user.getFailedLoginAttempts() >= 3) {
                user.setAccountNonLocked(false);
            }
            userRepository.save(user);
            throw new BadCredentialsException("Invalid email or password");
        }

        // successful login - reset failed attempts and run fraud checks
        user.setFailedLoginAttempts(0);
        userRepository.save(user);
        fraudDetectionService.evaluateLogin(user, loginHistory);
        auditService.log(user.getEmail(), "LOGIN", "Successful login from IP " + loginHistory.getIpAddress());

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        return AuthResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .fullName(user.getFullName())
                .email(user.getEmail())
                .role(user.getRole().name())
                .build();
    }

    private String resolveClientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
