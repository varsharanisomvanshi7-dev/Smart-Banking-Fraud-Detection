package com.bank.frauddetection.repository;

import com.bank.frauddetection.entity.LoginHistory;
import com.bank.frauddetection.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface LoginHistoryRepository extends JpaRepository<LoginHistory, Long> {
    List<LoginHistory> findByUserAndLoginTimeAfterOrderByLoginTimeDesc(User user, LocalDateTime since);
    List<LoginHistory> findTop10ByUserOrderByLoginTimeDesc(User user);
}
