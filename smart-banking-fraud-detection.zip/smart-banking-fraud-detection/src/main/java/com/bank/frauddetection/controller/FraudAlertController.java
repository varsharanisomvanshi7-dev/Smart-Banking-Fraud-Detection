package com.bank.frauddetection.controller;

import com.bank.frauddetection.entity.FraudAlert;
import com.bank.frauddetection.repository.FraudAlertRepository;
import com.bank.frauddetection.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/fraud-alerts")
@RequiredArgsConstructor
public class FraudAlertController {

    private final FraudAlertRepository fraudAlertRepository;

    @GetMapping("/me")
    public List<FraudAlert> myAlerts(@AuthenticationPrincipal UserPrincipal principal) {
        return fraudAlertRepository.findByUserIdOrderByCreatedAtDesc(principal.getUser().getId());
    }
}
