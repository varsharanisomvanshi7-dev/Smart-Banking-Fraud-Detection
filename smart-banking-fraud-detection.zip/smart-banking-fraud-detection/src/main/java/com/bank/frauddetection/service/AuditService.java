package com.bank.frauddetection.service;

import com.bank.frauddetection.entity.AuditLog;
import com.bank.frauddetection.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    public void log(String actor, String action, String details) {
        AuditLog entry = AuditLog.builder()
                .actor(actor)
                .action(action)
                .details(details)
                .build();
        auditLogRepository.save(entry);
    }
}
