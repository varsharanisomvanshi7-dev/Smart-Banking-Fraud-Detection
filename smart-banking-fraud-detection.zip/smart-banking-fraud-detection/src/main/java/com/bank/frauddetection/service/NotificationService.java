package com.bank.frauddetection.service;

import com.bank.frauddetection.entity.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Sends alerts to customers/admins.
 * This is a stub implementation that logs notifications - wire in an
 * actual email (JavaMailSender) or SMS gateway provider for production use.
 */
@Service
@Slf4j
public class NotificationService {

    @Async
    public void sendFraudAlertNotification(User user, String message) {
        log.warn("[FRAUD ALERT] To: {} ({}) | Message: {}", user.getFullName(), user.getEmail(), message);
        // TODO: integrate with an email/SMS provider, e.g.:
        // mailSender.send(buildAlertEmail(user, message));
    }

    @Async
    public void sendAccountFrozenNotification(User user, String reason) {
        log.warn("[ACCOUNT FROZEN] To: {} ({}) | Reason: {}", user.getFullName(), user.getEmail(), reason);
    }

    @Async
    public void sendTransactionNotification(User user, String message) {
        log.info("[TRANSACTION] To: {} ({}) | Message: {}", user.getFullName(), user.getEmail(), message);
    }
}
